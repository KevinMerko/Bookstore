package com.znipp.bookstore.controllers;

import com.znipp.bookstore.main;
import com.znipp.bookstore.models.bookModel;
import com.znipp.bookstore.models.cartModel;
import com.znipp.bookstore.models.userModel;
import com.znipp.bookstore.services.dbConsumer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Popup;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Objects;

public class mainViewController {

    cartModel cart = new cartModel();
    dbConsumer db = new dbConsumer();
    userModel user;

    @FXML
    private Label mainLabel;

    @FXML
    private Button searchBtn;

    @FXML
    private TextField searchField;

    @FXML
    private VBox resultVbox;

    @FXML
    private Button inventoryBtn;

    @FXML
    private Button settingsBtn;

    @FXML
    private Button usersBtn;

    @FXML
    private Button dashboardBtn;


    @FXML
    private Button checkoutCartBtn;

    @FXML
    void dashboardHandle() throws IOException {
        System.out.println("Dashboard");
        mainLabel.setText("Dashboard");
        searchVisibility(false);
        clearView();
        VBox loadedBox = FXMLLoader.load(Objects.requireNonNull(main.class.getResource("views/dashboard.fxml")));
        resultVbox.getChildren().add(loadedBox);
    }

    @FXML
    void exploreHandle() throws SQLException, IOException {
        System.out.println("Explore");
        mainLabel.setText("Explore");
        searchVisibility(true);
        clearView();
        searchEvent("");
    }

    @FXML
    void inventoryHandle() throws IOException {
        System.out.println("Inventory");
        mainLabel.setText("Inventory");
        searchVisibility(false);
        clearView();
        VBox loadedBox = FXMLLoader.load(Objects.requireNonNull(main.class.getResource("views/inventory.fxml")));
        resultVbox.getChildren().add(loadedBox);
    }

    @FXML
    void logoutHandle(ActionEvent event) throws IOException {
        System.out.println("Log out");
        searchVisibility(false);
        double height = ((Node)event.getSource()).getScene().getHeight();
        double width = ((Node)event.getSource()).getScene().getWidth();
        FXMLLoader fxmlLoader = new FXMLLoader(main.class.getResource("views/login.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), width, height);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    }

    @FXML
    void ordersHandle() throws IOException {
        System.out.println("Orders");
        mainLabel.setText("Orders");
        searchVisibility(false);
        clearView();
        VBox loadedBox = FXMLLoader.load(Objects.requireNonNull(main.class.getResource("views/orders.fxml")));
        resultVbox.getChildren().add(loadedBox);
    }

    @FXML
    void searchHandle() throws SQLException, IOException {
        System.out.println(searchField.getText());
        clearView();
        searchEvent(searchField.getText());
    }


    @FXML
    void settingsHandle() throws IOException {
        System.out.println("Settings");
        mainLabel.setText("Settings");
        searchVisibility(false);
        clearView();
        VBox loadedBox = FXMLLoader.load(Objects.requireNonNull(main.class.getResource("views/settings.fxml")));
        resultVbox.getChildren().add(loadedBox);
    }

    @FXML
    void usersHandle() throws IOException {
        System.out.println("Users");
        mainLabel.setText("Users");
        searchVisibility(false);
        clearView();
        VBox loadedBox = FXMLLoader.load(Objects.requireNonNull(main.class.getResource("views/users.fxml")));
        resultVbox.getChildren().add(loadedBox);
    }

    @FXML
    void checkoutCartHandle(ActionEvent event) throws IOException {
        System.out.println(cart);
        Popup popup = new Popup();

        FXMLLoader fxmlLoader = new FXMLLoader(main.class.getResource("views/cart.fxml"));
        VBox loadedBox = fxmlLoader.load();
        cartController childController = fxmlLoader.getController();
        childController.setCart(cart, user, popup);

        popup.getContent().add(loadedBox);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        popup.show(window);
    }

    void searchVisibility(Boolean value){
        searchField.setVisible(value);
        searchBtn.setVisible(value);
        checkoutCartBtn.setVisible(value);
    }

    void clearView(){
        Pane empty_pane = new Pane();
        empty_pane.setMaxHeight(20.0);
        resultVbox.getChildren().clear();
        resultVbox.getChildren().add(empty_pane);
    }

    public void setUser(userModel user) throws IOException, SQLException {
        this.user = user;
        switch (user.getRole()) {
            case "LIBRARIAN" -> {
                inventoryBtn.setVisible(false);
                settingsBtn.setVisible(false);
                usersBtn.setVisible(false);
                dashboardBtn.setVisible(false);
                exploreHandle();
            }
            case "MANAGER" -> {
                settingsBtn.setVisible(false);
                usersBtn.setVisible(false);
                dashboardHandle();
            }
            default -> {
                dashboardHandle();
            }
        }
    }

    public void searchEvent(String query) throws IOException, SQLException {
        ResultSet rs = db.select("SELECT * from book where title like '%" + query + "%';");

        while(rs.next()){
            System.out.println(rs.getString("title"));
            FXMLLoader fxmlLoader = new FXMLLoader(main.class.getResource("views/result.fxml"));
            HBox loadedBox = fxmlLoader.load();
            resultController childController = fxmlLoader.getController();
            bookModel book = new bookModel();
            book.setId(rs.getInt("id"));
            book.setTitle(rs.getString("title"));
            book.setAuthor(rs.getString("author"));
            book.setCategory(rs.getString("category"));
            book.setIsbn(rs.getString("isbn"));
            book.setStock(rs.getInt("stock"));
            book.setPurchase_date(rs.getString("purchase_date"));
            book.setPurchase_price(rs.getInt("purchase_price"));
            book.setSelling_price(rs.getInt("selling_price"));
            book.setSupplier(rs.getString("supplier"));
            childController.updateFields(book);
            resultVbox.getChildren().add(loadedBox);
            childController.setCart(cart);
        }
    }
}
