package com.znipp.bookstore.controllers;

import com.znipp.bookstore.services.dbConsumer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.*;
import javafx.scene.control.DatePicker;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class dashboardController {

    @FXML
    private BarChart<String, Number> barChart;

    @FXML
    private DatePicker fromDatePicker;

    @FXML
    private LineChart<String, Number> lineChart;

    @FXML
    private PieChart pieChart;

    @FXML
    private DatePicker toDatePicker;

    @FXML
    void periodChangeHandle(ActionEvent event) {

    }

    @FXML
    public void initialize() throws SQLException {
        dbConsumer db = new dbConsumer();

        // Get Data for the Pie Chart
        ResultSet ordersPerUserRs = db.select("SELECT u.username, count(user_id) as count FROM orders o INNER JOIN users u ON o.user_id = u.id GROUP by user_id;");
        Map<String, Number> pieData = new HashMap<>();
        while(ordersPerUserRs.next()){
            pieData.put(ordersPerUserRs.getString("username"), ordersPerUserRs.getInt("count"));
        }

        // Get Data for the Bar Chart
        ResultSet bestBooksRs = db.select("SELECT b.title, count(book_id) as count FROM order_details o INNER JOIN book b ON o.book_id = b.id GROUP by book_id;");
        Map<String, Number> barData = new HashMap<>();
        while(bestBooksRs.next()){
            barData.put(bestBooksRs.getString("title"), bestBooksRs.getInt("count"));
        }

        // Get Data for the Line Chart
        ResultSet dateSellsRs = db.select("SELECT date, sum(total) as total from orders GROUP by date;");
        Map<String, Number> lineData = new HashMap<>();
        while(dateSellsRs.next()){
            lineData.put(dateSellsRs.getString("date"), dateSellsRs.getInt("total"));
        }

        // Populating Bar Chart
        for(Map.Entry<String, Number> set: barData.entrySet()){
            XYChart.Series<String, Number> series1 = new XYChart.Series<>();
            series1.setName(set.getKey());
            series1.getData().add(new XYChart.Data<>("Book", set.getValue()));
            barChart.getData().add(series1);
        }

        // Populating Pie Chart
        for(Map.Entry<String, Number> set: pieData.entrySet()){
            PieChart.Data slice1 = new PieChart.Data(set.getKey(), set.getValue().doubleValue());
            pieChart.getData().add(slice1);
        }

        // Populating Line Chart
        XYChart.Series<String, Number> dataSeries1 = new XYChart.Series<>();
        for(Map.Entry<String, Number> set: lineData.entrySet()){
            dataSeries1.getData().add(new XYChart.Data<>( set.getKey(), set.getValue()));
        }
        lineChart.getData().add(dataSeries1);

    }

}
