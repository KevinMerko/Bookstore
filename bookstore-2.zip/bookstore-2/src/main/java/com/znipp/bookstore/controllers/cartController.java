package com.znipp.bookstore.controllers;

import com.znipp.bookstore.main;
import com.znipp.bookstore.models.bookModel;
import com.znipp.bookstore.models.cartModel;
import com.znipp.bookstore.models.userModel;
import com.znipp.bookstore.services.dbConsumer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Popup;

import java.io.IOException;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

public class cartController {

    private final dbConsumer db = new dbConsumer();

    private cartModel cart;

    private userModel user;

    private Popup popup;

    private int total = 0;

    @FXML
    private VBox resultVbox;

    @FXML
    private Label totalLabel;

    @FXML
    void emptyCartHandle(ActionEvent event) {
        System.out.println("emptying the cart");
        cart.setCart(new HashMap<>());
        resultVbox.getChildren().clear();
    }

    @FXML
    void sellHandle(ActionEvent event) throws SQLException {
        long millis=System.currentTimeMillis();

        // creating a new object of the class Date
        String strDate = new SimpleDateFormat("dd-MM-yyyy").format(new java.sql.Date(millis));

        db.updateInsert(String.format("INSERT INTO orders (date, total, user_id) values ('%s','%s','%s');", strDate, total, user.getId()));
        ResultSet rs = db.select("select seq from sqlite_sequence where name='orders';");
        int lastId = rs.getInt("seq");
        rs.close();
        for (Map.Entry<bookModel, Number> entry : cart.getCart().entrySet()) {
            bookModel book = entry.getKey();
            int value = (Integer) entry.getValue();
            db.updateInsert(String.format("INSERT INTO order_details (order_id, book_id, quantity, total_price) values (%d, %d, %d, %d);", lastId, book.getId(), value, (book.getSelling_price() * value) ));
        }
        popup.hide();
    }

    public void setCart(cartModel cart, userModel user, Popup popup){
        this.cart = cart;
        this.user = user;
        this.popup = popup;

        final HBox[] loadedBox = {null};
        for (Map.Entry<bookModel, Number> entry : cart.getCart().entrySet()) {
            bookModel key = entry.getKey();
            Number value = entry.getValue();
            FXMLLoader fxmlLoader = new FXMLLoader(main.class.getResource("views/cartElement.fxml"));
            try {
                loadedBox[0] = fxmlLoader.load();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            cartElementController childController = fxmlLoader.getController();
            childController.setData(key, (Integer) value, cart, totalLabel);
            resultVbox.getChildren().add(loadedBox[0]);
            total = total + (key.getSelling_price() * (Integer) value);
        }
        totalLabel.setText(String.valueOf(total));

    }
}
