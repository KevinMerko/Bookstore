package com.znipp.bookstore.models;

import java.util.HashMap;
import java.util.Map;

public class cartModel {

    Map<bookModel, Number> cart = new HashMap<>();

    public Map<bookModel, Number> getCart() {
        return cart;
    }

    public void setCart(Map<bookModel, Number> cart) {
        this.cart = cart;
    }

    @Override
    public String toString() {
        return "cartModel{" +
                "cart=" + cart +
                '}';
    }
}
