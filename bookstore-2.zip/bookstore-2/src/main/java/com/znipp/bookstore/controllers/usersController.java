package com.znipp.bookstore.controllers;

import com.znipp.bookstore.main;
import com.znipp.bookstore.models.userModel;
import com.znipp.bookstore.services.dbConsumer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Popup;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class usersController {

    @FXML
    private TableView<userModel> tableView;

    @FXML
    void newHandle(ActionEvent event) throws IOException {
        Popup popup = new Popup();
        FXMLLoader fxmlLoader = new FXMLLoader(main.class.getResource("views/userDetails.fxml"));
        VBox loadedBox = fxmlLoader.load();
        userDetailsController childController = fxmlLoader.getController();
        childController.setUser(new userModel(), false, popup);

        popup.getContent().add(loadedBox);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        popup.show(window);
    }

    @FXML
    public void initialize() throws SQLException {
        dbConsumer db = new dbConsumer();
        ResultSet rs = db.select("SELECT * FROM users;");

        List<userModel> users = new ArrayList<>();
        while(rs.next()){
            if(!rs.getString("role").equals("ADMIN")){
                userModel user = new userModel();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setRole(rs.getString("role"));
                users.add(user);
            }
        }
        TableColumn<userModel, String> username = new TableColumn<>("Username");
        username.setCellValueFactory(new PropertyValueFactory<>("username"));
        username.prefWidthProperty().bind(tableView.widthProperty().divide(2));

        TableColumn<userModel, String> role = new TableColumn<>("Role");
        role.setCellValueFactory(new PropertyValueFactory<>("role"));
        role.prefWidthProperty().bind(tableView.widthProperty().divide(2));

        ObservableList<userModel> list = FXCollections.observableArrayList(users);
        tableView.setItems(list);
        tableView.getColumns().addAll(username, role);

        tableView.setRowFactory( tv -> {
            TableRow<userModel> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                Popup popup = new Popup();
                if (event.getClickCount() == 2 && (! row.isEmpty()) ) {
                    userModel rowData = row.getItem();
                    System.out.println(rowData);
                    FXMLLoader fxmlLoader = new FXMLLoader(main.class.getResource("views/userDetails.fxml"));
                    VBox loadedBox = null;
                    try {
                        loadedBox = fxmlLoader.load();
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    userDetailsController childController = fxmlLoader.getController();
                    childController.setUser(rowData, true, popup);

                    popup.getContent().add(loadedBox);
                    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
                    popup.show(window);


                }
            });
            return row ;
        });

    }

}
