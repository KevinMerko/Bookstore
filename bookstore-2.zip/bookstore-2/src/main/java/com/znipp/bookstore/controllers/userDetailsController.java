package com.znipp.bookstore.controllers;

import com.znipp.bookstore.models.userModel;
import com.znipp.bookstore.services.dbConsumer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Popup;

import java.security.NoSuchAlgorithmException;

import static com.znipp.bookstore.controllers.loginController.getSHA;
import static com.znipp.bookstore.controllers.loginController.toHexString;

public class userDetailsController {

    dbConsumer db = new dbConsumer();

    private Popup popup;

    private Boolean from;

    private userModel user;

    @FXML
    private TextField passwordField;

    @FXML
    private ComboBox<String> roleCombo;

    @FXML
    private TextField usernameField;

    @FXML
    void cancelHandle(ActionEvent event) {
        popup.hide();
    }

    @FXML
    void saveHandle(ActionEvent event) throws NoSuchAlgorithmException {
        String username = usernameField.getText();
        String password = toHexString(getSHA(passwordField.getText()));
        String role = roleCombo.getValue();

        if(from){
            String sql = String.format("UPDATE users SET username = '%s', password = '%s', role = '%s' WHERE id = %s;", username, password, role, user.getId());
            System.out.println(sql);
            db.updateInsert(sql);
        } else {
            db.updateInsert(String.format("INSERT INTO users (username, password, role) values ('%s', '%s', '%s');", username, password, role));
        }
        popup.hide();


    }

    public void setUser(userModel user, boolean from, Popup popup){
        this.from = from;
        this.user = user;
        this.popup = popup;
        roleCombo.getItems().addAll("LIBRARIAN", "MANAGER");
        if(this.from){
            usernameField.setText(user.getUsername());
            roleCombo.setValue(user.getRole());
        }
    }

}
