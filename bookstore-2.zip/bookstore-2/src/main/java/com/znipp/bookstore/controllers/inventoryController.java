package com.znipp.bookstore.controllers;

import com.znipp.bookstore.main;
import com.znipp.bookstore.models.bookModel;
import com.znipp.bookstore.services.dbConsumer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Popup;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class inventoryController {

    @FXML
    private TableView<bookModel> tableView;

    @FXML
    void newHandle(ActionEvent event) {
        Popup popup = new Popup();
        FXMLLoader fxmlLoader = new FXMLLoader(main.class.getResource("views/inventoryDetails.fxml"));
        VBox loadedBox = null;
        try {
            loadedBox = fxmlLoader.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        inventoryDetailsController childController = fxmlLoader.getController();
        childController.setBook(new bookModel(), popup, false);

        popup.getContent().add(loadedBox);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        popup.show(window);
    }

    @FXML
    public void initialize() throws SQLException {
        dbConsumer db = new dbConsumer();
        ResultSet rs = db.select("SELECT * FROM book;");

        List<bookModel> books = new ArrayList<>();
        while(rs.next()){
            bookModel book = new bookModel();
            book.setId(rs.getInt("id"));
            book.setTitle(rs.getString("title"));
            book.setAuthor(rs.getString("author"));
            book.setCategory(rs.getString("category"));
            book.setIsbn(rs.getString("isbn"));
            book.setStock(rs.getInt("stock"));
            book.setPurchase_date(rs.getString("purchase_date"));
            book.setPurchase_price(rs.getInt("purchase_price"));
            book.setSelling_price(rs.getInt("selling_price"));
            book.setSupplier(rs.getString("supplier"));
            books.add(book);
        }
        TableColumn<bookModel, String> title = new TableColumn<>("Title");
        title.setCellValueFactory(new PropertyValueFactory<>("title"));
        title.prefWidthProperty().bind(tableView.widthProperty().divide(2));

        TableColumn<bookModel, String> stock = new TableColumn<>("Quantity");
        stock.setCellValueFactory(new PropertyValueFactory<>("stock"));
        stock.prefWidthProperty().bind(tableView.widthProperty().divide(8));

        TableColumn<bookModel, String> purchaseDate = new TableColumn<>("Purchase Date");
        purchaseDate.setCellValueFactory(new PropertyValueFactory<>("purchase_date"));
        purchaseDate.prefWidthProperty().bind(tableView.widthProperty().divide(6));

        TableColumn<bookModel, String> purchasePrice = new TableColumn<>("Purchase Price");
        purchasePrice.setCellValueFactory(new PropertyValueFactory<>("purchase_price"));
        purchasePrice.prefWidthProperty().bind(tableView.widthProperty().divide(6));

        ObservableList<bookModel> list = FXCollections.observableArrayList(books);
        tableView.setItems(list);
        tableView.getColumns().addAll(title, stock, purchaseDate, purchasePrice);

        tableView.setRowFactory( tv -> {
            TableRow<bookModel> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                Popup popup = new Popup();
                if (event.getClickCount() == 2 && (! row.isEmpty()) ) {
                    bookModel rowData = row.getItem();
                    System.out.println(rowData);
                    FXMLLoader fxmlLoader = new FXMLLoader(main.class.getResource("views/inventoryDetails.fxml"));
                    VBox loadedBox = null;
                    try {
                        loadedBox = fxmlLoader.load();
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    inventoryDetailsController childController = fxmlLoader.getController();
                    childController.setBook(rowData, popup, true);

                    popup.getContent().add(loadedBox);
                    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
                    popup.show(window);


                }
            });
            return row ;
        });

    }
}
