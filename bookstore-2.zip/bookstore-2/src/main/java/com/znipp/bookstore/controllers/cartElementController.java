package com.znipp.bookstore.controllers;

import com.znipp.bookstore.models.bookModel;
import com.znipp.bookstore.models.cartModel;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Popup;

import java.util.Map;

public class cartElementController {

    private bookModel book;

    private cartModel cart;

    private int quantity;

    private Label totalLabel;
    @FXML
    private Label quantityLbl;

    @FXML
    private Label titleLbl;

    @FXML
    void removeElementHandle(ActionEvent event) {
        Map<bookModel, Number> cartMap = cart.getCart();
        cartMap.remove(book);
        Node thisElement = (Node)event.getSource();
        VBox scrollBox = (VBox)thisElement.getParent().getParent();
        scrollBox.getChildren().remove(thisElement.getParent());
        totalLabel.setText(String.valueOf(Integer.parseInt(totalLabel.getText())  - (book.getSelling_price() * quantity)));
    }
    public void setData(bookModel book, int quantity, cartModel cart, Label totalLabel){
        this.book = book;
        this.cart = cart;
        this.quantity = quantity;
        this.totalLabel = totalLabel;
        titleLbl.setText(book.getTitle());
        quantityLbl.setText(quantityLbl.getText() + quantity);
    }


}
