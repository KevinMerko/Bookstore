package com.znipp.bookstore.controllers;

import com.znipp.bookstore.models.bookModel;
import com.znipp.bookstore.services.dbConsumer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Popup;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class inventoryDetailsController {

    dbConsumer db = new dbConsumer();

    private bookModel book;

    private Popup popup;

    private Boolean from;

    @FXML
    private TextField authorField;

    @FXML
    private TextField categoryField;

    @FXML
    private TextField isbnField;

    @FXML
    private DatePicker purchaseDateField;

    @FXML
    private TextField purchasePriceField;

    @FXML
    private TextField quantityField;

    @FXML
    private TextField sellingPriceField;

    @FXML
    private TextField supplierField;

    @FXML
    private TextField titleField;

    @FXML
    void cancelHandle(ActionEvent event) {
        popup.hide();
    }

    @FXML
    void saveHandle(ActionEvent event) {
        popup.hide();
        DateTimeFormatter formatters = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        String title = titleField.getText();
        String author = authorField.getText();
        String category = categoryField.getText();
        String isbn = isbnField.getText();
        String quantity = quantityField.getText();
        String purchaseDate = purchaseDateField.getValue().format(formatters);
        String purchasePrice = purchasePriceField.getText();
        String sellingPrice = sellingPriceField.getText();
        String supplier = supplierField.getText();
        if(from){
            db.updateInsert(String.format("UPDATE book SET title='%s', author='%s', category='%s', isbn='%s', " +
                            "stock=%s, purchase_date='%s', purchase_price=%s, selling_price=%s, " +
                            "supplier='%s' WHERE id=%d;",
                    title, author, category, isbn,
                    quantity, purchaseDate,
                    purchasePrice, sellingPrice, supplier, book.getId()
            ));
        } else {
            db.updateInsert(String.format("INSERT INTO book " +
                    "(title, author, category, isbn, stock, purchase_date, purchase_price, selling_price, supplier) " +
                    "VALUES ('%s', '%s', '%s', '%s', %s, '%s', %s, %s, '%s');",
                    title, author, category, isbn,
                    quantity, purchaseDate,
                    purchasePrice, sellingPrice, supplier));
        }
    }

    public void setBook(bookModel book, Popup popup, Boolean from){
        this.book = book;
        this.popup = popup;
        this.from = from;
        if(from){
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            LocalDate date = LocalDate.parse(book.getPurchase_date(), formatter);
            titleField.setText(book.getTitle());
            authorField.setText(book.getAuthor());
            categoryField.setText(book.getCategory());
            isbnField.setText(book.getIsbn());
            quantityField.setText(String.valueOf(book.getStock()));
            purchaseDateField.setValue(date);
            purchasePriceField.setText(String.valueOf(book.getPurchase_price()));
            sellingPriceField.setText(String.valueOf(book.getSelling_price()));
            supplierField.setText(book.getSupplier());
        }

    }

}
