package com.znipp.bookstore.controllers;

import com.znipp.bookstore.main;
import com.znipp.bookstore.models.orderModel;
import com.znipp.bookstore.models.userModel;
import com.znipp.bookstore.services.dbConsumer;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ordersController {

    @FXML
    private DatePicker fromDatePicker;

    @FXML
    private TableView<orderModel> tableView;

    @FXML
    private DatePicker toDatePicker;

    @FXML
    void newHandle(ActionEvent event) throws IOException {
        System.out.println("Adding new record");
    }

    @FXML
    void periodChangeHandle(ActionEvent event) {

    }

    @FXML
    public void initialize() throws SQLException {
        dbConsumer db = new dbConsumer();
        ResultSet rs = db.select("SELECT date, total, u.username, u.id FROM orders o INNER JOIN users u on o.user_id = u.id;");

        List<orderModel> orders = new ArrayList<>();
        while(rs.next()){
            orderModel order = new orderModel();
            order.setDate(rs.getString("date"));
            order.setTotal(rs.getInt("total"));
            userModel user = new userModel();
            user.setUsername(rs.getString("username"));
            user.setId(rs.getInt("id"));
            order.setUser(user);
            orders.add(order);
        }
        TableColumn<orderModel, String> date = new TableColumn<>("Date");
        date.setCellValueFactory(new PropertyValueFactory<>("date"));
        date.prefWidthProperty().bind(tableView.widthProperty().divide(3));

        TableColumn<orderModel, Number> total = new TableColumn<>("Total");
        total.setCellValueFactory(new PropertyValueFactory<>("total"));
        total.prefWidthProperty().bind(tableView.widthProperty().divide(3));

        TableColumn<orderModel, String> user = new TableColumn<>("User");
        user.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getUser().getUsername()));
        user.prefWidthProperty().bind(tableView.widthProperty().divide(3));

        ObservableList<orderModel> list = FXCollections.observableArrayList(orders);
        tableView.setItems(list);
        tableView.getColumns().addAll(date, total, user);

    }

}
