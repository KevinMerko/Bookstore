package com.znipp.bookstore.controllers;

import com.znipp.bookstore.models.companyDetailModel;
import com.znipp.bookstore.services.dbConsumer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import java.sql.ResultSet;
import java.sql.SQLException;

public class settingsController {

    companyDetailModel companyDetails = new companyDetailModel();
    private Boolean mode = false;
    @FXML
    private TextField addressField;

    @FXML
    private TextField emailField;

    @FXML
    private TextField nameField;

    @FXML
    private TextField numberField;

    @FXML
    private TextField tinField;

    @FXML
    private Button button;

    @FXML
    private Button cancelBtn;

    @FXML
    public void initialize() throws SQLException {
        populateFields();
    }

    @FXML
    void buttonHandle(ActionEvent event) throws SQLException {
        buttonHelper();
        if(!mode){
            dbConsumer db = new dbConsumer();
            db.updateInsert(String.format("UPDATE company_details SET name = '%s', address = '%s', number = '%s', email = '%s', tin = '%s' WHERE id = %d; ",
                    nameField.getText(),
                    addressField.getText(),
                    numberField.getText(),
                    emailField.getText(),
                    tinField.getText(),
                    companyDetails.getId())
            );
        }else{
            populateFields();
        }
    }

    @FXML
    void cancelHandle(ActionEvent event) throws SQLException {
        buttonHelper();
        populateFields();
    }

    void buttonHelper(){
        cancelBtn.setVisible(!mode);
        button.setText(mode ? "Edit" : "Save");
        addressField.setEditable(!mode);
        emailField.setEditable(!mode);
        nameField.setEditable(!mode);
        numberField.setEditable(!mode);
        tinField.setEditable(!mode);
        mode = !mode;
    }

    void populateFields() throws SQLException {
        dbConsumer db = new dbConsumer();
        ResultSet rs = db.select("Select * from company_details LIMIT 1;");

        while(rs.next()){
            companyDetails.setId(rs.getInt("id"));
            companyDetails.setName(rs.getString("name"));
            nameField.setText(rs.getString("name"));
            companyDetails.setAddress(rs.getString("address"));
            addressField.setText(rs.getString("address"));
            companyDetails.setNumber(rs.getString("number"));
            numberField.setText(rs.getString("number"));
            companyDetails.setEmail(rs.getString("email"));
            emailField.setText(rs.getString("email"));
            companyDetails.setTin(rs.getString("tin"));
            tinField.setText(rs.getString("tin"));
        }
    }

}
