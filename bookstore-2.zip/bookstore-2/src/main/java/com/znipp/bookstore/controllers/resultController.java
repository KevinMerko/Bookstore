package com.znipp.bookstore.controllers;

import com.znipp.bookstore.models.bookModel;
import com.znipp.bookstore.models.cartModel;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.util.Map;

public class resultController {

    cartModel cart;

    bookModel book;
    @FXML
    private Label authorLbl;

    @FXML
    private Label categoryLbl;

    @FXML
    private Label isbnLbl;

    @FXML
    private Label purchaseDtLbl;

    @FXML
    private Label purchasePriceLbl;

    @FXML
    private Label sellingPriceLbl;

    @FXML
    private Label stockLbl;

    @FXML
    private Label supplierLbl;

    @FXML
    private Label titleLbl;

    @FXML
    private TextField quantityField;

    @FXML
    void cartHandle(ActionEvent event) {
        System.out.println("Added to cart");
        Map<bookModel, Number> cartMap = cart.getCart();
        cartMap.put(book, Integer.valueOf(quantityField.getText()));
        quantityField.setText(null);
    }

    public void updateFields(bookModel book){
        this.book = book;
        titleLbl.setText(book.getTitle());
        categoryLbl.setText(book.getCategory());
        authorLbl.setText(book.getAuthor());
        isbnLbl.setText(book.getIsbn());
        stockLbl.setText(stockLbl.getText() + " " + book.getStock());
        purchaseDtLbl.setText(purchaseDtLbl.getText() + " " + book.getPurchase_date());
        purchasePriceLbl.setText(purchasePriceLbl.getText() + " " + book.getPurchase_price());
        sellingPriceLbl.setText(sellingPriceLbl.getText() + " " + book.getSelling_price());
        supplierLbl.setText(supplierLbl.getText() + " " + book.getSupplier());
    }

    public void setCart(cartModel cart){
        this.cart = cart;
    }

}
