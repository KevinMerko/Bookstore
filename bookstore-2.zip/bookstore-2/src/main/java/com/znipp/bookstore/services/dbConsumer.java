package com.znipp.bookstore.services;

import com.znipp.bookstore.main;

import java.sql.*;

public class dbConsumer {

    public ResultSet select(String sql){
        ResultSet rs = null;
        try{
            Connection conn = this.connect();
            Statement stmt  = conn.createStatement();
            rs = stmt.executeQuery(sql);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return rs;
    }

    public void updateInsert(String sql){
        try{
            Connection conn = this.connect();
            Statement stmt  = conn.createStatement();
            stmt.executeUpdate(sql);
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }


    private Connection connect() {
        // db parameters
        String url = String.valueOf(main.class.getResource("db/data.db")).replace("file:/","jdbc:sqlite:");
        // create a connection to the database
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }
}
