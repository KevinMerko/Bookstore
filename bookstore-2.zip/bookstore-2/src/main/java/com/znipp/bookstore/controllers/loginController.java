package com.znipp.bookstore.controllers;

import com.znipp.bookstore.main;
import com.znipp.bookstore.models.userModel;
import com.znipp.bookstore.services.dbConsumer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.Node;
import javafx.stage.Stage;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class loginController {

    @FXML
    private Button login_btn;

    @FXML
    private PasswordField password;

    @FXML
    private TextField username;

    @FXML
    void loginHandle(ActionEvent event) throws IOException, NoSuchAlgorithmException, SQLException {
        System.out.println("logging in as:" + " " +  username.getText() + " - " + password.getText());

        String passwordHash = toHexString(getSHA(password.getText()));
        System.out.println(passwordHash);

        dbConsumer db = new dbConsumer();
        ResultSet rs = db.select(String.format("Select * from users where username = '%s' LIMIT 1;", username.getText()));

        userModel user = new userModel();

        while(rs.next()){
            user.setId(rs.getInt("id"));
            user.setUsername(rs.getString("username"));
            user.setPassword(rs.getString("password"));
            user.setRole(rs.getString("role"));
        }
        System.out.println(user);

        System.out.println("PASS: " + user.getPassword());
        if(user.getPassword().equals(passwordHash)) { //(username.getText().equals("admin") && password.getText().equals("1234")){
            System.out.println("Login successful");
            double height = ((Node)event.getSource()).getScene().getHeight();
            double width = ((Node)event.getSource()).getScene().getWidth();
            FXMLLoader fxmlLoader = new FXMLLoader(main.class.getResource("views/mainView.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), width, height);
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            mainViewController childController = fxmlLoader.getController();
            childController.setUser(user);
            window.setScene(scene);
            window.setMaximized(true);
            window.show();
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initOwner(((Node)event.getSource()).getScene().getWindow());
            alert.setTitle("Warning");
            alert.setHeaderText("Username or password is incorrect");
            alert.showAndWait();
        }
    }

    public static byte[] getSHA(String input) throws NoSuchAlgorithmException
    {
        /* MessageDigest instance for hashing using SHA256 */
        MessageDigest md = MessageDigest.getInstance("SHA-256");

        /* digest() method called to calculate message digest of an input and return array of byte */
        return md.digest(input.getBytes(StandardCharsets.UTF_8));
    }

    public static String toHexString(byte[] hash)
    {
        /* Convert byte array of hash into digest */
        BigInteger number = new BigInteger(1, hash);

        /* Convert the digest into hex value */
        StringBuilder hexString = new StringBuilder(number.toString(16));

        /* Pad with leading zeros */
        while (hexString.length() < 32)
        {
            hexString.insert(0, '0');
        }

        return hexString.toString();
    }

}
