module com.znipp.bookstore {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.znipp.bookstore to javafx.fxml;
    opens com.znipp.bookstore.controllers to javafx.fxml;
    opens com.znipp.bookstore.models to javafx.base;
    exports com.znipp.bookstore;
}